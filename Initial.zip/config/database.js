module.exports = {
    url :"mongodb+srv://akshathdsza98:root123@akshath.vepeb6r.mongodb.net/book_db"
};